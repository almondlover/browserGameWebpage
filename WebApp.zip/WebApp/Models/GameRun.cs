﻿namespace WebApp.Models
{
    public class GameRun
    {
        public UserData user { get; set; }
        public Score score { get; set; }
        
    }
}
