//const menu=document.getElementById("sideMenu");
//const chapters=Array.from(menu.getElementsByTagName("a"))
//;
//const target=document.getElementById("instructionBlock");
//const instructionContent=[];

//for (const chapter of chapters)
//{
//    chapter.addEventListener("click", ()=>target.innerText=instructionContent[chapters.indexOf(this)]);
//}

//nishto